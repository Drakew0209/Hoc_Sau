# Bài tập Xấp xỉ hàm số dùng MLP bằng PyTorch

## Cấu trúc thư mục
- `dataset.py`: Xử lý sinh hàm Gaussian, chia tập dữ liệu.
- `model.py`: Định nghĩa kiến trúc lớp MLP (nn.Module).
- `train.py`: Vòng lặp huấn luyện, Backpropagation, Early Stopping.
- `experiments.py`: Tổ chức 3 kịch bản thực nghiệm A, B, C.
- `visualizer.py`: Vẽ biểu đồ 3D, phân tán và phân bố dữ liệu.
- `main.py`: Điểm neo chạy toàn bộ quy trình.

## Cách chạy mã nguồn
1. Cài đặt môi trường: `pip install -r requirements.txt`
2. Chạy toàn bộ luồng thực nghiệm: `python main.py`
Toàn bộ ảnh báo cáo (`.png`), trọng số mô hình tốt nhất (`.pth`), và nhật ký dữ liệu (`.csv`) sẽ được sinh ra trực tiếp trong cùng thư mục.