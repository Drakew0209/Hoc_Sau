import matplotlib.pyplot as plt
import numpy as np
import torch
import pandas as pd

def plot_data_3d(X, y, filename="data_3d_preview.png"):
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    sc = ax.scatter(X[:, 0], X[:, 1], y.flatten(), c=y.flatten(), cmap='viridis', marker='o', alpha=0.6)
    ax.set_xlabel('x1')
    ax.set_ylabel('x2')
    ax.set_zlabel('y (Mật độ)')
    plt.colorbar(sc, label='y value')
    plt.title('Dữ liệu phân bố chuẩn 2D sinh ngẫu nhiên')
    plt.savefig(filename)
    plt.close()

def plot_distributions(X, y, filename="data_distributions.png"):
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    axes[0].hist(X[:, 0], bins=30, color='blue', alpha=0.7)
    axes[0].set_title('Phân bố x1 (Miền [-2, 2])')
    axes[1].hist(X[:, 1], bins=30, color='green', alpha=0.7)
    axes[1].set_title('Phân bố x2 (Miền [-4, 4])')
    axes[2].hist(y, bins=30, color='red', alpha=0.7)
    axes[2].set_title('Phân bố y (Mật độ)')
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()
    print(f"Đã lưu biểu đồ phân bố tại {filename}")

def save_data_distribution(X, y, filename="data_distribution.csv"):
    df = pd.DataFrame({
        'x1': X[:, 0],
        'x2': X[:, 1],
        'y': y.flatten()
    })
    desc = df.describe()
    desc.to_csv(filename)
    df.to_csv("raw_data_samples.csv", index=False)
    print(f"Đã lưu thống kê tại {filename} và dữ liệu gốc tại raw_data_samples.csv")

def plot_y_true_vs_y_pred(y_true, y_pred, filename="y_true_vs_pred.png"):
    plt.figure(figsize=(8, 8))
    plt.scatter(y_true, y_pred, alpha=0.5, color='royalblue')
    max_val = max(np.max(y_true), np.max(y_pred))
    min_val = min(np.min(y_true), np.min(y_pred))
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', lw=2, label="Đường lý tưởng")
    plt.xlabel("Giá trị thực tế (y_true)")
    plt.ylabel("Giá trị dự đoán (y_pred)")
    plt.title("So sánh y_thật và y_dự đoán trên tập Test")
    plt.legend(); plt.grid(True)
    plt.savefig(filename); plt.close()

def plot_surfaces(model, device='cuda', filename="surface_comparison.png"):
    x1_range = np.linspace(-2, 2, 50)
    x2_range = np.linspace(-4, 4, 50)
    X1, X2 = np.meshgrid(x1_range, x2_range)
    
    mu = np.array([0, 0])
    C = np.array([[0.3, -0.5], [-0.5, 2.0]])
    inv_C = np.linalg.inv(C)
    det_C = np.linalg.det(C)
    
    Z_true = np.zeros_like(X1)
    Z_pred = np.zeros_like(X1)
    
    model.eval()
    with torch.no_grad():
        for i in range(X1.shape[0]):
            for j in range(X1.shape[1]):
                x_val = np.array([X1[i, j], X2[i, j]])
                diff = x_val - mu
                exponent = -0.5 * np.dot(np.dot(diff.T, inv_C), diff)
                Z_true[i, j] = (1.0 / (2 * np.pi * np.sqrt(det_C))) * np.exp(exponent)
                
                x_tensor = torch.tensor(x_val, dtype=torch.float32).unsqueeze(0).to(device)
                Z_pred[i, j] = model(x_tensor).item()
                
    fig = plt.figure(figsize=(16, 7))
    
    ax1 = fig.add_subplot(121, projection='3d')
    surf1 = ax1.plot_surface(X1, X2, Z_true, cmap='viridis', alpha=0.9, edgecolor='none')
    ax1.set_title("Bề mặt hàm Gaussian Thực Tế")
    ax1.set_xlabel('x1'); ax1.set_ylabel('x2'); ax1.set_zlabel('y')
    
    ax2 = fig.add_subplot(122, projection='3d')
    surf2 = ax2.plot_surface(X1, X2, Z_pred, cmap='plasma', alpha=0.9, edgecolor='none')
    ax2.set_title("Bề mặt Xấp Xỉ bằng mạng MLP")
    ax2.set_xlabel('x1'); ax2.set_ylabel('x2'); ax2.set_zlabel('y')
    
    plt.savefig(filename); plt.close()