import torch
import warnings
warnings.filterwarnings('ignore')
from dataset import generate_gaussian_2d, get_dataloaders
from experiments import run_experiment_A, run_experiment_B, run_experiment_C
from visualizer import save_data_distribution, plot_y_true_vs_y_pred, plot_surfaces, plot_data_3d, plot_distributions
from model import MLP
from train import train_model, evaluate_model

if __name__ == '__main__':
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Sử dụng thiết bị: {device}")
    
    print("1. Khởi tạo dữ liệu, vẽ biểu đồ phân bố và lưu log...")
    X, y = generate_gaussian_2d(n_samples=2000, seed=42)
    plot_data_3d(X, y, "data_3d_preview.png")
    plot_distributions(X, y, "data_distributions.png")
    save_data_distribution(X, y, "data_distribution.csv")
    
    print("\n2. Bắt đầu chạy các thực nghiệm kiểm soát (Nhóm A, B, C)...")
    run_experiment_A(device)
    run_experiment_B(device)
    run_experiment_C(device)
    
    print("\n3. Đánh giá chi tiết mô hình tối ưu (2 tầng, 10 nơ-ron)...")
    train_loader, val_loader, test_loader, _, _, _ = get_dataloaders(X, y, batch_size=32, test_size=100, seed=42)
    
    final_model = MLP(hidden_layers=2, hidden_neurons=10).to(device)
    final_model, _, _, _ = train_model(final_model, train_loader, val_loader, device=device)
    torch.save(final_model.state_dict(), "final_best_model.pth")
    
    mse, mae, rmse, all_preds, all_targets = evaluate_model(final_model, test_loader, device=device)
    print(f"Kết quả Test tập độc lập: MSE = {mse:.6f}, MAE = {mae:.6f}, RMSE = {rmse:.6f}")
    
    plot_y_true_vs_y_pred(all_targets, all_preds, "y_true_vs_pred.png")
    plot_surfaces(final_model, device=device, filename="surface_comparison.png")
    
    print("\nHOÀN TẤT THỰC THI MÃ NGUỒN!")