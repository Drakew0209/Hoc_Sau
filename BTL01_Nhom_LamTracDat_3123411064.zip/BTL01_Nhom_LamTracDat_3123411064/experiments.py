import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from dataset import generate_gaussian_2d, get_dataloaders
from model import MLP
from train import train_model, evaluate_model
import torch

SEEDS = [42, 43, 44, 45, 46]

def run_experiment_A(device='cuda'):
    sample_sizes = [200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000]
    avg_mses = []
    avg_rmses = []
    all_results = []

    print("\n--- THỰC NGHIỆM A: ẢNH HƯỞNG QUY MÔ DỮ LIỆU ---")
    for n in sample_sizes:
        seed_mses = []
        seed_rmses = []
        row_data = {'Size': n}

        for seed in SEEDS:
            torch.manual_seed(seed)
            X, y = generate_gaussian_2d(n_samples=n, seed=seed)
            train_loader, val_loader, test_loader, _, _, _ = get_dataloaders(X, y, seed=seed)
            model = MLP(hidden_layers=1, hidden_neurons=10).to(device)
            model, _, _, _ = train_model(model, train_loader, val_loader, device=device)
            mse, mae, rmse, _, _ = evaluate_model(model, test_loader, device=device)

            seed_mses.append(mse)
            seed_rmses.append(rmse)
            row_data[f'Seed_{seed}_MSE'] = mse
            row_data[f'Seed_{seed}_RMSE'] = rmse

        mean_mse = np.mean(seed_mses)
        std_mse = np.std(seed_mses)
        mean_rmse = np.mean(seed_rmses)
        std_rmse = np.std(seed_rmses)

        avg_mses.append(mean_mse)
        avg_rmses.append(mean_rmse)

        row_data['Mean_MSE'] = mean_mse
        row_data['Std_MSE'] = std_mse
        row_data['Mean_RMSE'] = mean_rmse
        row_data['Std_RMSE'] = std_rmse
        all_results.append(row_data)

        print(f"Size {n}: MSE = {mean_mse:.6f} ± {std_mse:.6f}, RMSE = {mean_rmse:.6f} ± {std_rmse:.6f}")

    df_A = pd.DataFrame(all_results)
    df_A.to_csv("experiment_A_results.csv", index=False)
    print("-> Đã lưu log số liệu thực nghiệm A vào 'experiment_A_results.csv'")

    plt.figure(figsize=(10, 5))
    plt.plot(sample_sizes, avg_mses, marker='o', lw=2, label='MSE', color='#0044cc')
    plt.plot(sample_sizes, avg_rmses, marker='s', lw=2, label='RMSE', color='red', linestyle='--')
    plt.title("Thực nghiệm A: Ảnh hưởng quy mô dữ liệu (Trung bình 5 seeds)")
    plt.xlabel("Số lượng mẫu (A)")
    plt.ylabel("Sai số")
    plt.legend()
    plt.grid(True)
    plt.savefig("exp_A.png")
    plt.close()

def run_experiment_B(device='cuda'):
    neurons = list(range(1, 11))
    avg_mses = []
    avg_rmses = []
    all_results = []

    print("\n--- THỰC NGHIỆM B: ẢNH HƯỞNG ĐỘ RỘNG (SỐ NƠ-RON) ---")
    for num_n in neurons:
        seed_mses = []
        seed_rmses = []
        row_data = {'Neurons': num_n}

        for seed in SEEDS:
            torch.manual_seed(seed)
            X, y = generate_gaussian_2d(n_samples=1500, seed=seed)
            train_loader, val_loader, test_loader, _, _, _ = get_dataloaders(X, y, seed=seed)
            model = MLP(hidden_layers=1, hidden_neurons=num_n).to(device)
            model, _, _, _ = train_model(model, train_loader, val_loader, device=device)
            mse, _, rmse, _, _ = evaluate_model(model, test_loader, device=device)

            seed_mses.append(mse)
            seed_rmses.append(rmse)
            row_data[f'Seed_{seed}_MSE'] = mse
            row_data[f'Seed_{seed}_RMSE'] = rmse

        mean_mse = np.mean(seed_mses)
        std_mse = np.std(seed_mses)
        mean_rmse = np.mean(seed_rmses)
        std_rmse = np.std(seed_rmses)

        avg_mses.append(mean_mse)
        avg_rmses.append(mean_rmse)

        row_data['Mean_MSE'] = mean_mse
        row_data['Std_MSE'] = std_mse
        row_data['Mean_RMSE'] = mean_rmse
        row_data['Std_RMSE'] = std_rmse
        all_results.append(row_data)

        print(f"{num_n} Neurons: MSE = {mean_mse:.6f} ± {std_mse:.6f}, RMSE = {mean_rmse:.6f} ± {std_rmse:.6f}")

    df_B = pd.DataFrame(all_results)
    df_B.to_csv("experiment_B_results.csv", index=False)
    print("-> Đã lưu log số liệu thực nghiệm B vào 'experiment_B_results.csv'")

    plt.figure(figsize=(10, 5))
    plt.plot(neurons, avg_mses, marker='o', lw=2, label='MSE', color='#0044cc')
    plt.plot(neurons, avg_rmses, marker='s', lw=2, label='RMSE', color='red', linestyle='--')
    plt.title("Thực nghiệm B: Ảnh hưởng độ rộng mạng")
    plt.xlabel("Số nơ-ron tầng ẩn (B)")
    plt.ylabel("Sai số")
    plt.xticks(neurons)
    plt.legend()
    plt.grid(True)
    plt.savefig("exp_B.png")
    plt.close()

def run_experiment_C(device='cuda'):
    layers = [1, 2, 3, 4]
    avg_mses = []
    avg_rmses = []
    avg_times = []
    all_results = []

    print("\n--- THỰC NGHIỆM C: ẢNH HƯỞNG ĐỘ SÂU (SỐ TẦNG ẨN) ---")
    for num_l in layers:
        seed_mses = []
        seed_rmses = []
        seed_times = []
        best_mse_for_layer = float('inf')
        row_data = {'Layers': num_l}

        for seed in SEEDS:
            torch.manual_seed(seed)
            X, y = generate_gaussian_2d(n_samples=1500, seed=seed)
            train_loader, val_loader, test_loader, _, _, _ = get_dataloaders(X, y, seed=seed)
            model = MLP(hidden_layers=num_l, hidden_neurons=10).to(device)
            model, _, _, t_time = train_model(model, train_loader, val_loader, device=device)
            mse, _, rmse, _, _ = evaluate_model(model, test_loader, device=device)

            seed_mses.append(mse)
            seed_rmses.append(rmse)
            seed_times.append(t_time)

            row_data[f'Seed_{seed}_MSE'] = mse
            row_data[f'Seed_{seed}_RMSE'] = rmse
            row_data[f'Seed_{seed}_Time'] = t_time

            if mse < best_mse_for_layer:
                best_mse_for_layer = mse
                torch.save(model.state_dict(), f"best_model_layer_{num_l}.pth")

        mean_mse = np.mean(seed_mses)
        std_mse = np.std(seed_mses)
        mean_rmse = np.mean(seed_rmses)
        std_rmse = np.std(seed_rmses)
        mean_time = np.mean(seed_times)
        std_time = np.std(seed_times)

        avg_mses.append(mean_mse)
        avg_rmses.append(mean_rmse)
        avg_times.append(mean_time)

        row_data['Mean_MSE'] = mean_mse
        row_data['Std_MSE'] = std_mse
        row_data['Mean_RMSE'] = mean_rmse
        row_data['Std_RMSE'] = std_rmse
        row_data['Mean_Time'] = mean_time
        row_data['Std_Time'] = std_time
        all_results.append(row_data)

        print(f"{num_l} Layers: MSE = {mean_mse:.6f} ± {std_mse:.6f}, RMSE = {mean_rmse:.6f} ± {std_rmse:.6f}, Time = {mean_time:.2f} ± {std_time:.2f}s")

    df_C = pd.DataFrame(all_results)
    df_C.to_csv("experiment_C_results.csv", index=False)
    print("-> Đã lưu log số liệu thực nghiệm C vào 'experiment_C_results.csv'")

    fig, ax1 = plt.subplots(figsize=(10, 5))
    ax1.set_xlabel('Số tầng ẩn (C)')
    ax1.set_ylabel('Sai số')
    ax1.plot(layers, avg_mses, marker='o', lw=2, color='#0044cc', label='MSE')
    ax1.plot(layers, avg_rmses, marker='s', lw=2, color='red', linestyle='--', label='RMSE')
    ax1.set_xticks(layers)

    ax2 = ax1.twinx()
    ax2.set_ylabel('Thời gian huấn luyện (giây)', color='purple')
    ax2.plot(layers, avg_times, marker='^', lw=2, color='purple', linestyle=':', label='Time')
    ax2.tick_params(axis='y', labelcolor='purple')

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='best')

    fig.tight_layout()
    plt.title("Thực nghiệm C: Đánh giá sai số và thời gian huấn luyện")
    plt.grid(True)
    plt.savefig("exp_C.png")
    plt.close()