import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader, random_split

def generate_gaussian_2d(n_samples=2000, seed=42):
    np.random.seed(seed)
    # Khắc phục lỗi miền dữ liệu: x1 trong [-2, 2], x2 trong [-4, 4] theo đúng yêu cầu bài toán
    x1 = np.random.uniform(-2, 2, n_samples)
    x2 = np.random.uniform(-4, 4, n_samples)
    X = np.column_stack((x1, x2))
    
    mu = np.array([0, 0])
    C = np.array([[0.3, -0.5], [-0.5, 2.0]])
    inv_C = np.linalg.inv(C)
    det_C = np.linalg.det(C)
    
    y = np.zeros((n_samples, 1))
    for i in range(n_samples):
        diff = X[i] - mu
        exponent = -0.5 * np.dot(np.dot(diff.T, inv_C), diff)
        y[i, 0] = (1.0 / (2 * np.pi * np.sqrt(det_C))) * np.exp(exponent)
    return X, y

def get_dataloaders(X, y, batch_size=32, test_size=100, seed=42):
    tensor_X = torch.tensor(X, dtype=torch.float32)
    tensor_y = torch.tensor(y, dtype=torch.float32)
    dataset = TensorDataset(tensor_X, tensor_y)
    
    train_val_size = len(dataset) - test_size
    train_size = int(0.7 * train_val_size)
    val_size = train_val_size - train_size
    
    generator = torch.Generator().manual_seed(seed)
    # Tách tập train, val, test độc lập
    train_ds, val_ds, test_ds = random_split(dataset, [train_size, val_size, test_size], generator=generator)
    
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False)
    
    return train_loader, val_loader, test_loader, train_size, val_size, test_size