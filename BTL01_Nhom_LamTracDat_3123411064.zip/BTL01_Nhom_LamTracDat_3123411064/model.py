import torch
import torch.nn as nn

class MLP(nn.Module):
    def __init__(self, input_size=2, hidden_layers=1, hidden_neurons=10, output_size=1):
        super(MLP, self).__init__()
        layers = []
        layers.append(nn.Linear(input_size, hidden_neurons))
        layers.append(nn.GELU())
        for _ in range(hidden_layers - 1):
            layers.append(nn.Linear(hidden_neurons, hidden_neurons))
            layers.append(nn.GELU())
        layers.append(nn.Linear(hidden_neurons, output_size))
        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)
