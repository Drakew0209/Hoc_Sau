"""Các phép tính cơ bản với hai số."""


def add(first_number, second_number):
    """Trả về tổng của hai số."""
    return first_number + second_number


def subtract(first_number, second_number):
    """Trả về hiệu của hai số."""
    return first_number - second_number


def multiply(first_number, second_number):
    """Trả về tích của hai số."""
    return first_number * second_number


def divide(first_number, second_number):
    """Trả về thương của hai số."""
    if second_number == 0:
        raise ValueError("Không thể chia cho 0.")
    return first_number / second_number


print("Kết quả chạy thử:")
print("Cộng: 8 + 2 =", add(8, 2))
print("Trừ: 8 - 2 =", subtract(8, 2))
print("Nhân: 8 * 2 =", multiply(8, 2))
print("Chia: 8 / 2 =", divide(8, 2))
